=== Plugin Name ===
Contributors: kode7
Donate link: https://kode7.it
Tags: widget
Requires at least: 4.6
Tested up to: 4.7
Stable tag: 4.3
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl.html

If you want to replace a default widget of a theme with blank emptyness, this plugin is your solution.

== Description ==

In a lot of themes the developers have defined default widgets that are shown in the footer or the sidebars. You can replace them by configure at least one widget at Design > Widgets for the specific area. There is no standard way to show no widget at all. To solve this problem I've created this plugin.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to Design > Widgets and use the widget wherever you want

== Frequently Asked Questions ==

None so far!

== Changelog ==

= 0.1.0 =
* Initial version
