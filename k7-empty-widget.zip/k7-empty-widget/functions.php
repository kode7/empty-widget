<?php
    add_action( 'widgets_init', function() { register_widget( 'K7_Empty_Widget' ); } );
